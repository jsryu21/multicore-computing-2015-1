#!/bin/bash
thorq --add --mode single --device cpu ./swaptions -ns 128 -sm 1000000
