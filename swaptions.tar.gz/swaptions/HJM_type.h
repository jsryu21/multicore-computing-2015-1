#ifndef __TYPE__
#define __TYPE__
//#define DEBUG

#if defined(BASELINE) && defined(ENABLE_SSE4)
#error BASELINE and ENABLE_SSE4 are mutually exclusive
#endif

#define FTYPE double
#define BLOCK_SIZE 16 // Blocking to allow better caching

#define RANDSEEDVAL 100
#define DEFAULT_NUM_TRIALS  102400

typedef struct
{
    FTYPE dSimSwaptionMeanPrice;
    FTYPE dSimSwaptionStdError;
    FTYPE dStrike;
    FTYPE dCompounding;
    FTYPE dMaturity;
    FTYPE dTenor;
    FTYPE dPaymentInterval;
    FTYPE dYears;
    int Id;
    int iN;
    int iFactors;
} parm;

#endif //__TYPE__
